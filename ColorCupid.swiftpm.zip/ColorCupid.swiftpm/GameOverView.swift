//
//  GameOverView.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 17/04/23.
//

import SwiftUI

struct GameOverView: View {
    var body: some View {
        NavigationView{
            ZStack{
                Image("TimesUp")
                    .resizable()
                    .ignoresSafeArea()
                
                HStack{
                    Button{
                 
                    } label: {
                        NavigationLink(destination: MiniGame1View()){Image("TryAgain")}
                    }
                    
                    Button{
                        
                    } label: {
                        NavigationLink(destination: MainMenu()){Image("MainMenu")}
                    }  .offset(CGSize(width: -12, height:0))
                }.position(x:580, y:620)
            }
        }.navigationViewStyle(.stack).navigationBarBackButtonHidden(true)
    }
}

struct GameOverView_Previews: PreviewProvider {
    static var previews: some View {
        GameOverView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}

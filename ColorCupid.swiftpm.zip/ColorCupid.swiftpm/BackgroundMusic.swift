//
//  BackgroundMusic.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 19/04/23.
//

import Foundation
import AVFoundation
import UIKit

var audioPlayer: AVAudioPlayer!

func playMusic(music: String) {
    guard let audioData = NSDataAsset(name: music)?.data else {
             fatalError("Unable to find asset \(music)")
          }

          do {
             audioPlayer = try AVAudioPlayer(data: audioData)
              audioPlayer.numberOfLoops = -1
              audioPlayer.play()
          } catch {
             fatalError(error.localizedDescription)
        }
}

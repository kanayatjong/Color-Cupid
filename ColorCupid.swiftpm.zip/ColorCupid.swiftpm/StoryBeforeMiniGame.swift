//
//  StoryBeforeMiniGame.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 17/04/23.
//

import SwiftUI

struct StoryBeforeMiniGame: View {
    
    @State var leftOffset = CGSize(width: -500, height: 0)
    @State var rightOffset = CGSize(width: 500, height: 0)
    @State var storyImageName = "StoryPage1"
    @State var index = 0
    @State var navigationOn = false
    
    @State var appeared: Double = 0
    var body: some View {
        
        NavigationView{
            
            ZStack{
                Image(storyImageName)
                    .resizable()
                    .ignoresSafeArea()
                
                Image("GordenLeft")
                    .offset(leftOffset)
                Image("GordenRight")
                    .offset(rightOffset)
                
                Image("GordenTop").offset(CGSize(width:0, height:-2))
                
                NavigationLink("", destination: MiniGame1View(), isActive: $navigationOn)
                
            }
            .onTapGesture {
                withAnimation(.easeIn(duration: 1.0)) {
                    leftOffset = CGSizeZero
                    rightOffset = CGSizeZero
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){
                    withAnimation(.easeOut(duration: 1.3)) {
                        leftOffset = CGSize(width: -500, height: 0)
                        rightOffset = CGSize(width: 500, height: 0)
                    }
                }
                
                print(index)
                print(storyImageName)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                    switch index {
                    case 1:
                        storyImageName = "StoryPage2"
                    case 2:
                        storyImageName = "StoryPage3"
                    case 3:
                        storyImageName = "StoryPage4"
                    case 4:
                        storyImageName = "StoryPage5"
                    case 5:
                        storyImageName = "StoryPage6"
                    case 6:
                        storyImageName = "StoryPage7"
                    case 7:
                        storyImageName = "StoryPage8"
                    case 8:
                        storyImageName = "StoryPage9"
                    case 9:
                        storyImageName = "StoryPage10"
                    default:
                        navigationOn = true
                    }
                }

                index+=1
                
            }
        }.navigationViewStyle(.stack).navigationBarBackButtonHidden(true)
            .opacity(appeared)
            .animation(Animation.easeIn(duration: 1.0), value: appeared)
            .onAppear {self.appeared = 1.0}
            .onDisappear {self.appeared = 0.0}
    }
    init(){
        UINavigationBar.setAnimationsEnabled(false)
    }
}


struct StoryBeforeMiniGame_Previews: PreviewProvider {
    static var previews: some View {
        StoryBeforeMiniGame().previewInterfaceOrientation(.landscapeLeft)
    }
}

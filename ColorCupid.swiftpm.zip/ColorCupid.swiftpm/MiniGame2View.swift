//
//  MiniGame2View.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 17/04/23.
//

import SwiftUI

struct MiniGame2View: View {
    @State var opacityGuide = 0.0
    @State var countdown = 20.0
    @State var timer: Timer?
    @State var timeUp = false
    @State var imageName = "GreenMini2"
    @State var option1 = "Option1Mini2"
    @State var option2 = "Option2Mini2"
    @State var option3 = "Option3Mini2"
    @State var DisableDone = true
    @State var selectedAnswer2 = 0
    @State var appeared: Double = 0
    @State var finalAnswer2 : Int = UserDefaults.standard.integer(forKey: "finalAnswer2")
    @State private var isShowingMiniGame3View:Bool = false
        
    func removeOverlayButton() {
        switch
        (selectedAnswer2
        ){
        case 1:
            option1 = "Option1Mini2"
        case 2:
            option2 = "Option2Mini2"
        case 3:
            option3 = "Option3Mini2"
        default:
            return
        }
    }

    
    var body: some View {
        NavigationView {
            ZStack{
                Image("miniGame2Background")
                    .resizable()
                    .ignoresSafeArea()
                
                Image("\(imageName)")
                    .position(x:875 ,y:220)
                
                Button{
                   opacityGuide = 1
                } label: {
                    Image("GuideButton")
                }.position(x: 990, y: 470)
                
                ZStack{
                    Image("Timer").position(x:710 ,y:470)
                    Text(String(format: "%.0f", countdown))
                        .fontWeight(.heavy)
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                        .offset(CGSize(width: 150, height: 73))
                }
                
                HStack{
                    Button{
                     imageName = "GreenYellowBlueMini2"
                        removeOverlayButton()
                        option1 = "Option1Mini2Selected"
                        selectedAnswer2 = 1
                        DisableDone = false
                        finalAnswer2 = selectedAnswer2
                        UserDefaults.standard.set(finalAnswer2, forKey:"finalAnswer2")
                    } label: {
                        Image("\(option1)")
                    }
                    
                    Button{
                        imageName = "GreenYellowMini2"
                        removeOverlayButton()
                        option2 = "Option2Mini2Selected"
                        selectedAnswer2 = 2
                        DisableDone = false
                        finalAnswer2 = selectedAnswer2
                        UserDefaults.standard.set(finalAnswer2, forKey:"finalAnswer2")
                    } label: {
                        Image("\(option2)")
                    }  .offset(CGSize(width: -15, height:0))
                    
                    Button{
                        imageName = "GreenMagentaPurpleMini2"
                        removeOverlayButton()
                        option3 = "Option3Mini2Selected"
                        selectedAnswer2 = 3
                        DisableDone = false
                        finalAnswer2 = selectedAnswer2
                        UserDefaults.standard.set(finalAnswer2, forKey:"finalAnswer2")
                    } label: {
                        Image("\(option3)")
                    }  .offset(CGSize(width: -30, height:0))
                    
                    NavigationLink(destination: MiniGame3View(), isActive: $isShowingMiniGame3View) {
                        Button{
                            isShowingMiniGame3View = true
                            self.timer?.invalidate()
                            self.timer = nil
                        } label: {
                            Image("DoneButton")
                        }.offset(CGSize(width: -35, height: -5))
                    }
                    .disabled(DisableDone)
                }.position(x:600, y:680)
                
                ZStack {
                    Rectangle().ignoresSafeArea().opacity(0.2)
                    Image("Guide")
                    
                    Button{
                        opacityGuide=0
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .font(.system(size: 70)).foregroundColor(.white).shadow(radius: 10)
                    }.position(x: 1040, y: 220)
                }.opacity(opacityGuide)
                
                NavigationLink("", destination: GameOverView(), isActive: $timeUp)
            }
        }
        .onAppear {
            // start the timer when the view appears
            print("page1: \(self.countdown)")
            self.timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                if self.countdown > 0 {
                    self.countdown -= 1
                } else {
                    self.timeUp = true
                    self.timer?.invalidate()
                    self.timer = nil
                    
                }
            }
        }
        .onDisappear {
            self.timer?.invalidate()
            self.timer = nil
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
        .opacity(appeared)
        .animation(Animation.easeIn(duration: 1.0), value: appeared)
        .onAppear {self.appeared = 1.0}
        .onDisappear {self.appeared = 0.0}
    }
    
    init(){
        UINavigationBar.setAnimationsEnabled(false)
    }
}
struct MiniGame2View_Previews: PreviewProvider {
    static var previews: some View {
        MiniGame2View()
            .previewInterfaceOrientation(.landscapeLeft)
    }
    
}

//
//  MainMenu.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 17/04/23.
//

import SwiftUI

struct MainMenu: View {
    @State var opacityAbout = 0.0
    @State var opacityCredit = 0.0
    
    var body: some View {
        NavigationView{
            ZStack{
                Image("CoverMainMenu").resizable().ignoresSafeArea()
                
                HStack{

                    Button{
                        opacityAbout = 1
                    } label: {
                        Image("About")
                    }

                    Button{
                        
                    } label: {
                        NavigationLink(destination: StoryBeforeMiniGame()){ Image("Start")
                        }
                    }  .offset(CGSize(width: -12, height:0))
                    
                    Button{
                        opacityCredit = 1
                    } label: {
                        Image("Credit")
                    }  .offset(CGSize(width: -24, height:0))
                }.position(x:600, y:680)
                
                ZStack {
                    Rectangle().ignoresSafeArea().opacity(0.2)
                    Image("AboutColorCupid")
                    
                    Button{
                      opacityAbout = 0
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .font(.system(size: 70))
                            .foregroundColor(.white)
                            .shadow(radius:10)
                    }.position(x: 1020, y: 208)
                }.opacity(opacityAbout)
                
                ZStack {
                    Rectangle().ignoresSafeArea().opacity(0.2)
                    Image("MusicCredit")
                    
                    Button{
                      opacityCredit = 0
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.white)
                            .shadow(radius:10)
                    }.position(x: 970, y: 350)
                }.opacity(opacityCredit)
            }
        }.navigationViewStyle(.stack)
            .navigationBarBackButtonHidden(true)
            .onAppear{
               playMusic(music: "BackgroundMusic")
            }
    }
}

struct MainMenu_Previews: PreviewProvider {
    static var previews: some View {
        MainMenu().previewInterfaceOrientation(.landscapeLeft)
    }
}

//
//  MiniGameResult.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 18/04/23.
//

import SwiftUI

struct MiniGameResult: View {
    @State var finalAnswer1 : Int = UserDefaults.standard.integer(forKey: "finalAnswer1")
    @State var finalAnswer2 : Int = UserDefaults.standard.integer(forKey: "finalAnswer2")
    @State var finalAnswer3 : Int = UserDefaults.standard.integer(forKey: "finalAnswer3")
    
    var body: some View {
        NavigationView{
            ZStack{

                Image("resultBackground").resizable().ignoresSafeArea()
                Image("GordenTop").offset(CGSize(width:0, height:-2))
                VStack{
                    HStack{
                       
                        if(finalAnswer1 == 1){
                            Image("ResultOption1Mini1")
                                .offset(CGSize(width: 0, height:140))
                        }else if (finalAnswer1 == 2){
                            Image("ResultOption2Mini1")
                                .offset(CGSize(width: 0, height:140))
                        }else{
                            Image("ResultOption3Mini1")
                                .offset(CGSize(width: 0, height:140))
                        }
                        
                        if(finalAnswer2 == 1){
                            Image("ResultOption1Mini2")
                                .offset(CGSize(width: 0, height:140))
                        }else if (finalAnswer2 == 2){
                            Image("ResultOption2Mini2")
                                .offset(CGSize(width: 0, height:140))
                        }else{
                            Image("ResultOption3Mini2")
                                .offset(CGSize(width: 0, height:140))
                        }
                        
                        if(finalAnswer3 == 1){
                            Image("ResultOption1Mini3")
                                .offset(CGSize(width: 0, height:140))
                        }else if (finalAnswer3 == 2){
                            Image("ResultOption2Mini3")
                                .offset(CGSize(width: 0, height:140))
                        }else{
                            Image("ResultOption3Mini3")
                                .offset(CGSize(width: 0, height:140))
                        }
                        
                    }
                    
                    if(finalAnswer1 == 1 && finalAnswer2 == 2 && finalAnswer3 == 1){
                        Image("AllAnswerRight")
                            .offset(CGSize(width: 0, height:100))
                    }else if(finalAnswer1 == 1 || finalAnswer2 == 2 || finalAnswer3 == 1){
                        Image("SomeAnswerRight")
                            .offset(CGSize(width: 0, height:100))
                    }else{
                        Image("AllAnswerWrong")
                            .offset(CGSize(width: 0, height:100))
                    }
                    
                    Button{
                        print("tes")
                    } label: {
                        NavigationLink(destination: MainMenu()){Image("MainMenu")}
                    }  .offset(CGSize(width: -12, height:57))
                    
                }
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct MiniGameResult_Previews: PreviewProvider {
    static var previews: some View {
        MiniGameResult().previewInterfaceOrientation(.landscapeLeft)
    }
}

//
//  MiniGame1View.swift
//  ColorCupid
//
//  Created by Kanaya Tio on 17/04/23.
//

import SwiftUI

struct MiniGame1View: View {
    @State var opacityGuide = 0.0
    @State var countdown = 25.0
    @State var timer: Timer?
    @State var timeUp = false
    @State var imageName = "OrangeMini1"
    @State var option1 = "Option1Mini1"
    @State var option2 = "Option2Mini1"
    @State var option3 = "Option3Mini1"
    @State var DisableDone = true
    @State var selectedAnswer = 0
    @State var appeared: Double = 0
    @State var finalAnswer1 : Int = UserDefaults.standard.integer(forKey: "finalAnswer1")
    @State private var isShowingMiniGame2View:Bool = false
        
    func removeOverlayButton() {
        switch
        (selectedAnswer
        ){
        case 1:
            option1 = "Option1Mini1"
        case 2:
            option2 = "Option2Mini1"
        case 3:
            option3 = "Option3Mini1"
        default:
            return
        }
    }

    
    var body: some View {
        NavigationView {
            ZStack{
                Image("miniGame1Background")
                    .resizable()
                    .ignoresSafeArea()
                
                Image("\(imageName)")
                    .position(x:875 ,y:220)
                
                Button{
                   opacityGuide = 1
                } label: {
                    Image("GuideButton")
                }.position(x: 990, y: 470)
                
                ZStack{
                    Image("Timer").position(x:710 ,y:470)
                    Text(String(format: "%.0f", countdown))
                        .fontWeight(.heavy)
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                        .offset(CGSize(width: 150, height: 73))
                }
                
                HStack{
                    Button{
                     imageName = "OrangeBlueMini1"
                        removeOverlayButton()
                        option1 = "Option1Mini1Selected"
                        selectedAnswer = 1
                        DisableDone = false
                        finalAnswer1 = selectedAnswer
                        UserDefaults.standard.set(finalAnswer1, forKey:"finalAnswer1")
                    } label: {
                        Image("\(option1)")
                    }
                    
                    Button{
                        imageName = "YellowOrangeMini1"
                        removeOverlayButton()
                        option2 = "Option2Mini1Selected"
                        selectedAnswer = 2
                        DisableDone = false
                        finalAnswer1 = selectedAnswer
                        UserDefaults.standard.set(finalAnswer1, forKey:"finalAnswer1")
                    } label: {
                        Image("\(option2)")
                    }  .offset(CGSize(width: -15, height:0))
                    
                    Button{
                        imageName = "MagentaOrangeMini1Semen"
                        removeOverlayButton()
                        option3 = "Option3Mini1Selected"
                        selectedAnswer = 3
                        DisableDone = false
                        finalAnswer1 = selectedAnswer
                        UserDefaults.standard.set(finalAnswer1, forKey:"finalAnswer1")
                    } label: {
                        Image("\(option3)")
                    }  .offset(CGSize(width: -30, height:0))
                    
                    NavigationLink(destination: MiniGame2View(), isActive: $isShowingMiniGame2View) {
                        Button{
                            isShowingMiniGame2View = true
                            self.timer?.invalidate()
                            self.timer = nil
                        } label: {
                            Image("DoneButton")
                        }.offset(CGSize(width: -35, height: -5))
                    }
                    .disabled(DisableDone)
                }.position(x:600, y:680)
                
                ZStack {
                    Rectangle().ignoresSafeArea().opacity(0.2)
                    Image("Guide")
                    
                    Button{
                        opacityGuide=0
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .font(.system(size: 70)).foregroundColor(.white).shadow(radius: 10)
                    }.position(x: 1040, y: 220)
                }.opacity(opacityGuide)
                
                NavigationLink("", destination: GameOverView(), isActive: $timeUp)
            }
        }
        .onAppear {
            // start the timer when the view appears
            print("page1: \(self.countdown)")
            self.timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                if self.countdown > 0 {
                    self.countdown -= 1
                } else {
                    self.timeUp = true
                    self.timer?.invalidate()
                    self.timer = nil
                    
                }
            }
        }
        .onDisappear {
            self.timer?.invalidate()
            self.timer = nil
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
        .opacity(appeared)
        .animation(Animation.easeIn(duration: 1.0), value: appeared)
        .onAppear {self.appeared = 1.0}
        .onDisappear {self.appeared = 0.0}
    }
    
    init(){
        UINavigationBar.setAnimationsEnabled(false)
    }
}

struct MiniGame1View_Previews: PreviewProvider {
    static var previews: some View {
        MiniGame1View()
            .previewInterfaceOrientation(.landscapeLeft)
    }
    
}

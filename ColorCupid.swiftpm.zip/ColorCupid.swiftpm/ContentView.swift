import SwiftUI

struct ContentView: View {
    var body: some View {
      MainMenu()
    }
}

struct ContentView_preview: PreviewProvider{
    static var previews: some View{
        ContentView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
